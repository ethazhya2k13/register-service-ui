
import { EventEmitter, Injectable, Output } from '@angular/core';
import { RegisterRequest } from 'src/app/models/register-request';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginRequest } from 'src/app/models/login-request';
import { LoginResponse } from 'src/app/models/LoginResponse';
import { LocalStorageService } from 'ngx-webstorage';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
// import { roles } from 'src/app/models/Roles';
import { UserService } from './user.service';
import { Users } from '../models/Users';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  @Output() loggedIn: EventEmitter<boolean> = new EventEmitter();
  @Output() users: EventEmitter<string> = new EventEmitter();
  @Output() userName: EventEmitter<string> = new EventEmitter();
  @Output() roleName: EventEmitter<string> = new EventEmitter();
  @Output() roleId: EventEmitter<string> = new EventEmitter();
  // jwtTokenPayload = {
  //   jwtToken: this.getJwtToken(),
  //   users: this.getUsers(this.users),
  //   userName: this.getUserName(),
  //   roleName: this.getRoleName(),
  //   // roles: this.getRoles()
  // }
  private apiURL!: string;
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(
    private http: HttpClient,
    private localStorage: LocalStorageService,
    private userService: UserService
  ) {
    this.apiURL = environment.apiUrl;
  }

  register(registerDetails: RegisterRequest): Observable<any> {
    const url = `${this.apiURL}/${environment.apiEndpoints.adduser}`;
    return this.http.post(url, registerDetails, {
      responseType: 'text',
    });
  }
  //here the return type is any because it can return any thing a validation error, a validation msg, successful msg we dont know what it is exactly returning so we are mentioning it as any.
  login(loginDetails: LoginRequest) {
    const url = `${this.apiURL}/${environment.apiEndpoints.authenticate}`;
    return this.http
      .post<LoginResponse>(url, loginDetails, {
        headers: this.requestHeader,
       })
      //  .subscribe((LoginResponse) => {
      //   console.log(LoginResponse);
      //   this.getJwtToken();
      //   this.authStatusListener.next(true);
      //  }
       ;
      //  .pipe(
      //   map((data) => {
      //     this.localStorage.store('authenticationToken', data.jwtToken);
      //     this.localStorage.store('userDetails', data.users);
      //     this.localStorage.store('userName', data.userName);
      //     this.localStorage.store('roleName', data.roleName);
      //     this.localStorage.store('roles', data.roles);
      //     console.log(data.roleName);
      //     // console.log(data.roles);
      //     this.loggedIn.emit(true);
      //     this.userName.emit(data.userName);
      //     this.roleName.emit(data.roleName);
      //     return true;
        //  })
      //  );
  }
  // .pipe(
  //   map((data) => {
  //     this.localStorage.store('authenticationToken', data.jwtToken);
  //     this.localStorage.store('userDetails', data.users);
  //     this.localStorage.store('userName', data.userName);
  //     this.localStorage.store('roleName', data.roleName);
  //     this.localStorage.store('roles', data.roles);
  //     console.log(data.roleName);
  //     console.log(data.roles);
  //     this.loggedIn.emit(true);
  //     this.userName.emit(data.userName);
  //     this.roleName.emit(data.roleName);
  //     return true;
  //   })
  // );
  setToken(jwtToken: string) {
    localStorage.setItem('jwtToken', jwtToken);
  }
  getJwtToken():string {
    return localStorage.getItem('jwtToken') || '{}';
  }
  logout() {
   localStorage.removeItem("jwtToken");
   localStorage.removeItem("roles");
   localStorage.removeItem("roleName");
   localStorage.removeItem("users");
   localStorage.removeItem("userName");
  }
  public isLoggedIn(){
    //instance of jwthelper class
    //return this.getRoles() && this.getJwtToken();
    let token = localStorage.getItem('jwtToken');
    if(!token){
      return false;
    }
    //  return this.getJwtToken()!= null;
  }
  public getRoles(): [] {
    return JSON.parse(localStorage.getItem('roles') || '{}');
  }
  public setRoles(roles: []) {
    localStorage.setItem('roles', JSON.stringify(roles));
  }
  public getUsers():[] {
    return JSON.parse(localStorage.getItem('users')|| '{}');
  }
  public setUsers(users: []) {
    localStorage.setItem('users',JSON.stringify(users));
 }
 public setUserName(userName: string){
  localStorage.setItem('userName',userName);
}
  public getUserName():string {
  return localStorage.getItem('userName')|| '{}';
}
public setRoleName(roleName: string){
  localStorage.setItem('roleName',roleName);
}
  public getRoleName(): string {
  return localStorage.getItem('roleName')|| '{}';
}
  public roleMatch(allowedRoles: string | any[]): boolean | undefined {
    let isMatch = false;
    const userRoles: any = this.getRoles();
    //  console.log("User jwt role",userRoles);
    if (userRoles != null && userRoles) {
       for (let i = 0; i < userRoles.length; i++) {
        // console.log("User roles",userRoles);
         for (let j = 0; j < allowedRoles.length; j++) {
          // console.log("allowedRoles",allowedRoles);
          if (userRoles[i].roleName === allowedRoles[j]) {
            // console.log("iffffffffffffff");
            // console.log("user roles match",userRoles.roleName);
            isMatch = true;
            // console.log("ISMATCH rolematch",isMatch);
            return isMatch;
          } else {
            return isMatch;
          }
        }
      }
    }
  }
}
