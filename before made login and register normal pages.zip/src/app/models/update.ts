export class Update{
  firstName!: string;
  lastName!: string;
  userName!: string;
  userPassword!: string;
  userEmail!: string;
  userGender!: string;
  roleId!: number;
}
