import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';
import { Users } from 'src/app/models/Users';
import { UserService } from 'src/app/services/user.service';
import { UsersListComponent } from '../users-list/users-list.component';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {

  users: Users[] = [];
  addUserForm!:FormGroup;
  constructor(private authService: AuthService,
    private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) public editData: any,
    private dialog:MatDialogRef<AddUserComponent>,
    private router: Router,
    private usersService: UserService) {}

  ngOnInit(): void {

    this.addUserForm = new FormGroup({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      userName: new FormControl('',[Validators.required]),
      userPassword: new FormControl('',[Validators.required]),
      userEmail: new FormControl('', [Validators.required, Validators.email]),
      userGender: new FormControl('', [Validators.required]),
      });
    }

    addUsers(){
      if(this.addUserForm.valid){
        this.usersService.addUser(this.addUserForm.value)
        .subscribe({
          next:(response)=>{
            alert("User added successfully");
            this.addUserForm.reset();
            this.dialog.close('save');
          },
          error:()=>{
            //username already present ah irukanu parthu check pannanum panitu suitable error msg throw pannanum.
            alert("Error while adding User")
          }
        })
      }
    }
}
