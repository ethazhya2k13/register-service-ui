import { Component,  EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog'
import { LoginComponent } from '../login/login.component';
import { AuthService } from 'src/app/services/auth.service';
import { UserService } from 'src/app/services/user.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Output() toggleSidebarForMe: EventEmitter<any> = new EventEmitter();
  isLoggedIn: boolean = false;
  userName: any;
  constructor(private router: Router,public dialog: MatDialog,private authService: AuthService, public userService: UserService) { }

  ngOnInit(){
  if((this.authService.isLoggedIn())){
    this.router.navigate(['/home',localStorage.getItem('userName')]);
  }
  // else{
  //   // this.dialog.open(LoginComponent, {
  //   //   data: {},
  //   })
  }


  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    this.authService.loggedIn.subscribe((data: boolean) => this.isLoggedIn = data);
    this.authService.userName.subscribe((data: string) => this.userName = data);
    // this.isLoggedIn = this.authService.isLoggedIn();
    this.userName = this.authService.getUserName();
  }
  toggleSidebar() {
    this.toggleSidebarForMe.emit();
  }

  login(){
    const dialogRef = this.dialog.open(LoginComponent, {
      data: {},
    })
  }


  logout(){
    this.authService.logout();
    this.isLoggedIn = false;
    this.router.navigateByUrl('');
  }
}
