import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  usersCount!: number
  rolesCount!: number
  constructor( private usersService: UserService) { }

  ngOnInit() {
this.getUserCount();
console.log(this.getUserCount());
this.getRolesCount();
console.log(this.getRolesCount());
  }
  getUserCount(){
    this.usersService.getUsersCount().subscribe(users => {
      this.usersCount = users;
    })
  }
  getRolesCount(){
    this.usersService.getRolesCount().subscribe(roles => {
      this.rolesCount = roles;
    })
  }
}
