export interface LoginRequest{
  userName: string;
  userPassword: string;
}
