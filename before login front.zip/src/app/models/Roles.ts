export class Roles{
  roleId!: Number;
  roleName!: string;
  roleDescription!: string;
}
