import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { MatDialog} from '@angular/material/dialog'
import { LoginComponent } from '../login/login.component';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private authService: AuthService,  private router:Router,public dialog: MatDialog) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if(request.headers.get('No-Auth') === 'True'){
    return next.handle(request.clone());
  }
  const token = this.authService.getJwtToken();
  request = this.addToken(request, token);

  return next.handle(request).pipe(
    catchError(
      (err:HttpErrorResponse)=>{
        console.log(err.status);
        if(err.status === 401){
             this.router.navigate(['/home']);
          }
          else if(err.status === 403){
            this.router.navigate(['/forbidden']);
          }
          return throwError("Something went wrong");
          }
    )
  );
  }

  private addToken(request:HttpRequest<any>, token:string){
    return request.clone(
      {
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      }
    )
  }
}
//This interceptor acts as a filter for each request. It checks if authorization header is present in the HTTP request or not and if present continue with the header else it will add authorization header in HTTP request.
// We can add an interceptor, which are functions that will run on any outgoing HTTP request, and we can then manipulate these outgoing requests, for example, to attach our token, and that is exactly what we want to do.
//https://www.javatpoint.com/adding-token-to-authenticate-requests-in-mean-stack
