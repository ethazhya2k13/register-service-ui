import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl, NgForm } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { LoginRequest } from 'src/app/models/login-request';
import { throwError } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { RegisterComponent } from '../register/register.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  hide = true;
  loginForm!: FormGroup;  //! = by compiler telling it is not assigned, by using this ! we are telling the compiler that the value for this will be assigned later or will be assigned in the runtime.
  loginRequest!: LoginRequest;
  loginSuccessMessage!: string;
  isError!: boolean;
 constructor(private authService: AuthService,private activatedRoute: ActivatedRoute,
    private router: Router,   public dialog: MatDialog) {
    this.loginRequest = {
      userName: '',
      userPassword: ''
    };
  }


  ngOnInit() { //this lifecycle hooks gets triggered when the component gets initiated. for eg: all the loading stuffs are placed inside this.
    this.loginForm = new FormGroup({
      userName: new FormControl(''),
      // userName: new FormControl('',[Validators.required, Validators.pattern('^[a-zA-Z0-9]([._-](?![._-])|[a-zA-Z0-9]){3,18}[a-zA-Z0-9]$',),]),
      userPassword: new FormControl('',[Validators.required])
      // userPassword: new FormControl('',[Validators.required, Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$')])
  });

  this.activatedRoute.queryParams
  .subscribe(params => {
    if(params['registered']!==undefined && params['registered'] === 'true'){
    }
  });
}

  loginSubmit(loginForm: any){

    this.authService.login(loginForm.value).subscribe(
      (data:any) => {
      this.authService.setRoles(data.users.roles);
      this.authService.setToken(data.jwtToken);
      this.authService.setUsers(data.users);
      this.authService.setUserName(data.userName);
      this.authService.setRoleName(data.roleName);
      localStorage.setItem('isLoggedIn','true');
      const roles = data.roles.roleName;
      console.log("login role",roles);
      if(roles === 'Admin'){
        this.router.navigate(['/users']);
      }else{
        this.router.navigate(['/home']);
      }
      console.log(data)
      this.dialog.closeAll();
      alert("login successfull");

      },
      error=> {
        console.log(error);
      }
      );
    }



  public isLoginFormDirty():boolean{
    return this.loginForm.dirty || this.loginForm.touched;
  }

  canDeactivate():Observable<boolean> | boolean{
    if(this.isLoginFormDirty()){
      return confirm("Are you sure you want to leave this page? You will lose your changes!");
    }
    return true;
  }

  register(){
    const dialogRef = this.dialog.open(RegisterComponent, {
      data: {},
    })
  }

  public isLoggedIn(){
    return localStorage.getItem('isLoggedIn') === 'true';
  }


  public logout(){
    this.authService.logout();
  }
}

