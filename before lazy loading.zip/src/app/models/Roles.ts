export interface Roles{
  roleId: Number;
  roleName: string;
  roleDescription: string;
}
