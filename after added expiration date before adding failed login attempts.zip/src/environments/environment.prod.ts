import { EnvironmentConfiguration } from "src/app/models/environment-configuration";

export const environment: EnvironmentConfiguration = {
  production: true,
  env_name: "dev",
  apiUrl: "http://localhost:786",
  apiEndpoints: {
    admin: "admin",
    user:"user",
    authenticate: "authenticate",
    register: "user",
    delete: "user/delete",
    users: "users",
    userById: "users",
    update: "users",
    roles: "roles",
    usersrole: "usersrole"
  },
  cacheTimeInMinutes: 30,
};
