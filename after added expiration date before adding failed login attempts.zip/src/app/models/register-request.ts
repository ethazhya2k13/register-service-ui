export interface RegisterRequest {
  firstName: string;
  lastName: string;
  userEmail: string;
  userGender: string;
  userName: string;
  userPassword: string;
}
