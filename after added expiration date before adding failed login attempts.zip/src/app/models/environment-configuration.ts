export interface EnvironmentConfiguration {
  env_name: string;
  production: boolean;
  apiUrl: string;
  apiEndpoints: {
    admin: string;
    user:string;
    authenticate: string,
    register: string;
    delete: string;
    users: string;
    userById: string;
    update: string;
    roles: string;
    usersrole: string;
  },
  cacheTimeInMinutes: number;
}
