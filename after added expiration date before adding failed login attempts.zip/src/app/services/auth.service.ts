import { EventEmitter, Injectable, Output } from '@angular/core';
import { RegisterRequest } from 'src/app/models/register-request';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { LoginRequest } from 'src/app/models/login-request';
import { LoginResponse } from 'src/app/models/LoginResponse';
import { LocalStorageService } from 'ngx-webstorage';
import { shareReplay, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { DateService } from './date.service';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  @Output() loggedIn: EventEmitter<boolean> = new EventEmitter();
  @Output() users: EventEmitter<string> = new EventEmitter();
  @Output() userName: EventEmitter<string> = new EventEmitter();
  private apiURL!: string;
  constructor(
    private http: HttpClient,
    private localStorage: LocalStorageService,
    private dateService: DateService
  ) {
    this.apiURL = environment.apiUrl;
  }

  register(registerDetails: RegisterRequest): Observable<any> {
    const url = `${this.apiURL}/${environment.apiEndpoints.register}`;
    return this.http.post(url, registerDetails, {
      responseType: 'text',
    });
  }
//here the return type is any because it can return any thing a validation error, a validation msg, successful msg we dont know what it is exactly returning so we are mentioning it as any.
  login(loginDetails: LoginRequest): Observable<LoginResponse> {
    const url = `${this.apiURL}/${environment.apiEndpoints.authenticate}`;
    return this.http
      .post<LoginResponse>(url, loginDetails)
      .pipe(
        tap((res: LoginResponse) => this.setSession(res)),
        shareReplay()

      );
  }

  //tap = performs actions or side-effects." In this case, it's invoking the setSession() function.
  //shareReplay =  handles a situation when the observable has multiple subscribers. If there's a johnny-come-lately in the mix, I want that last subscriber to get the last value emitted by the Observable.
// Moreover, I want it to do that without invoking another network call.
// In a nutshell, that's what shareReplay() does.


  // login(loginDetails: LoginRequest): Observable<boolean> {
  //   const url = `${this.apiURL}/${environment.apiEndpoints.authenticate}`;
  //   return this.http
  //     .post<LoginResponse>(url, loginDetails)
  //     .pipe(
  //       map((data) => {
  //         this.localStorage.store('authenticationToken', data.jwtToken);
  //         this.localStorage.store('userDetails', data.users);
  //         this.localStorage.store('userName', data.userName);
  //         this.localStorage.store('expiration date', data.expirationDate);
  //         this.loggedIn.emit(true);
  //         return true;
  //       })
  //     );
  // }
//pipe() = it is a function that allows to connect a series of functions that return observables. inside pipe() we find one or more operators called as pipeable operators. actions which take on the observable that gets sent back to the subscriber.
// You can also store quite a bit of data in localStorage: up to 10 Mb.

private setSession(authResult: LoginResponse){
  const expiresAt = authResult.expirationDate;
  console.log("Token expires at "+expiresAt);
  console.log("Token date and expires at "+this.dateService.getShortDateAndTimeDisplay(expiresAt));
  localStorage.setItem('authenticationToken',authResult.jwtToken);
  localStorage.setItem('UserName',authResult.userName);
  localStorage.setItem('expires_at',JSON.stringify(expiresAt.valueOf()));
  this.loggedIn.emit(true);
  this.userName.emit(authResult.userName);
}

getJwtToken(){
    return this.localStorage.retrieve('authenticationToken');
  }

  //when you use localStorage you'll avoid some of the security vulnerabilities you would notice when you use cookies.
  logout(){
    localStorage.removeItem("expires_at");
    localStorage.removeItem("UserName");
    localStorage.removeItem("authenticationToken");

  }

  // getUsers(){
  //   return this.localStorage.retrieve('userDetails');
  // }

  getUserName(){
    const userName = localStorage.getItem('UserName');
    return userName;
    // return this.localStorage.retrieve('userName');
  }

  getExpiration(): number{
    const expiration = localStorage.getItem("expires_at");
    const expiresAt = JSON.parse(expiration!);
    return expiresAt;
  }

  isLoggedIn(): boolean{
    // return Date.now()<this.getExpiration();
    return this.getJwtToken()!=null;
  }

  isLoggedOut(): boolean{
    return !this.isLoggedIn();
  }

}
