import { Component, OnInit } from '@angular/core';
import {FormGroup, Validators, FormControl } from '@angular/forms';
import { RegisterRequest } from '../../models/register-request';
import { AuthService } from 'src/app/services/auth.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  registerForm!: FormGroup ;
  registerDetails!: RegisterRequest;
  constructor(private authService: AuthService, private router: Router, public dialog: MatDialog) {
   this.registerDetails = {
    firstName: '',
    lastName: '',
    userEmail: '',
    userGender: '',
    userName: '',
    userPassword: ''
   };
 }

 ngOnInit(){
  this.registerForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    userEmail: new FormControl('', [Validators.required, Validators.email]),
    userGender: new FormControl('', [Validators.required]),
    userName: new FormControl('',[Validators.required]),
    userPassword: new FormControl('',[Validators.required])
  });
}

registerSubmit(){
   this.registerDetails.firstName = this.registerForm.get('firstName')?.value;
   this.registerDetails.lastName = this.registerForm.get('lastName')?.value;
   this.registerDetails.userEmail = this.registerForm.get('userEmail')?.value;
   this.registerDetails.userGender = this.registerForm.get('userGender')?.value;
   this.registerDetails.userName = this.registerForm.get('userName')?.value;
   this.registerDetails.userPassword = this.registerForm.get('userPassword')?.value;

   this.authService.register(this.registerDetails)
   .subscribe(data => {
      this.login();

   }, error => {
    console.log(error);

   });

  }

  public isFormDirty():boolean{
    return this.registerForm.dirty || this.registerForm.touched;
  }

  canDeactivate():Observable<boolean> | boolean{
    if(this.isFormDirty()){
      return confirm("Are you sure you want to leave this page? You will lose your changes!");
    }
    return true;
  }

  login(){
    const dialogRef = this.dialog.open(LoginComponent, {
      data: {},
    })
  }
}
