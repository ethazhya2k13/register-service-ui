export interface LoginResponse{
  users: string;
  jwtToken: string;
  userName: string;
  roleName: string;
  roles: string;
}
