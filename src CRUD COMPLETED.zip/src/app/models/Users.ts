export class Users {
  userId!: number;
  firstName!: string;
  lastName!: string;
  userName!: string;
  userPassword!: string;
  userEmail!: string;
  userGender!: string;
  created!: string;
  updatedAt!: string;
  roleId!: number;
  roleName!: string;
}
