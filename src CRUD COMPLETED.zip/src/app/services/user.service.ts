import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable } from 'rxjs';
import { Users } from 'src/app/models/Users';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Roles } from 'src/app/models/Roles';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiURL!: string;
  constructor(private http: HttpClient) {
    this.apiURL = environment.apiUrl;
   }

   getAllUsers(): Observable<Users[]>{
    const getAllUsersurl = `${this.apiURL}/${environment.apiEndpoints.usersrole}`;
    return this.http.get<Users[]>(getAllUsersurl);
   }

   updateUser(userId:number, update: Users): Observable<any>{
    const updateUsersUrl = `${this.apiURL}/${environment.apiEndpoints.update}/${userId}`;
    return this.http.put(updateUsersUrl,update,{responseType: 'text'});
   }

   addUser(user: Users): Observable<any>{
    const addUserUrl = `${this.apiURL}/${environment.apiEndpoints.register}`;
    return this.http.post(addUserUrl,user,{responseType: 'text'});
   }

   deleteUser(userId: number):Observable<any>{
    const deleteUserUrl = `${this.apiURL}/${environment.apiEndpoints.delete}/${userId}`;
    return this.http.delete(deleteUserUrl,{responseType: 'text'});
  }

  getAllRoles(): Observable<Roles[]>{
    const rolesUrl = `${this.apiURL}/${environment.apiEndpoints.roles}`;
    return this.http.get<Roles[]>(rolesUrl);
  }

  getUserById(userId: number): Observable<Users[]>{
    const getUserByIdUrl = `${this.apiURL}/${environment.apiEndpoints.userById}/${userId}`;
    return this.http.get<Users[]>(getUserByIdUrl);
  }

}
