import { EventEmitter, Injectable, Output } from '@angular/core';
import { RegisterRequest } from 'src/app/models/register-request';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { LoginRequest } from 'src/app/models/login-request';
import { LoginResponse } from 'src/app/models/LoginResponse';
import { LocalStorageService } from 'ngx-webstorage';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  @Output() loggedIn: EventEmitter<boolean> = new EventEmitter();
  @Output() users: EventEmitter<string> = new EventEmitter();
  @Output() userName: EventEmitter<string> = new EventEmitter();
  @Output() roleName: EventEmitter<string> = new EventEmitter();
  jwtTokenPayload = {
    jwtToken: this.getJwtToken(),
    users: this.getUsers(),
    userName: this.getUserName(),
    // roleName: this.getRoleName()
  }
  private apiURL!: string;
  constructor(
    private http: HttpClient,
    private localStorage: LocalStorageService
  ) {
    this.apiURL = environment.apiUrl;
  }

  register(registerDetails: RegisterRequest): Observable<any> {
    const url = `${this.apiURL}/${environment.apiEndpoints.register}`;
    return this.http.post(url, registerDetails, {
      responseType: 'text',
    });
  }
//here the return type is any because it can return any thing a validation error, a validation msg, successful msg we dont know what it is exactly returning so we are mentioning it as any.
  login(loginDetails: LoginRequest): Observable<boolean> {
    const url = `${this.apiURL}/${environment.apiEndpoints.authenticate}`;
    return this.http
      .post<LoginResponse>(url, loginDetails)
      .pipe(
        map((data) => {
          this.localStorage.store('authenticationToken', data.jwtToken);
          this.localStorage.store('userDetails', data.users);
          this.localStorage.store('userName', data.userName);
          this.loggedIn.emit(true);
          this.userName.emit(data.userName);
          return true;
        })
      );
  }

  getJwtToken(){
    return this.localStorage.retrieve('authenticationToken');
  }

  logout(){
    this.localStorage.clear('authenticationToken');
    this.localStorage.clear('userDetails');
    this.localStorage.clear('userName');
  }

  getUsers(){
    return this.localStorage.retrieve('userDetails');
  }

  getUserName(){
    return this.localStorage.retrieve('userName');
  }

  isLoggedIn(): boolean{
    return this.getJwtToken()!=null;
  }

}
